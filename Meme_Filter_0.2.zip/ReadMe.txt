You've added and downloaded some custom sounds for you filter. Those sound files need to be placed in the same folder as your filter file.

This is a list of all used custom sounds:
- carti-what-sound-made-with-Voicemod.mp3
- anime-mwah!-made-with-Voicemod.mp3
- meme-made-with-Voicemod.mp3
- lapis-lazuli-made-with-Voicemod.mp3
- fbi-open-up!-(sound-effect)-made-with-Voicemod.mp3
- whopper-whopper-whopper-whopper-made-with-Voicemod(1).mp3
- bang-bang-2-made-with-Voicemod.mp3
- im-omning-it-made-with-Voicemod.mp3
